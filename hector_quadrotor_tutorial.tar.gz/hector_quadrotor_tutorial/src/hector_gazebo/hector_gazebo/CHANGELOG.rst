^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package hector_gazebo
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.3.6 (2015-03-21)
------------------

0.3.5 (2015-02-23)
------------------

0.3.4 (2014-09-01)
------------------
* Removed package gazebo_rtt_plugin
  This package is obsolete. Use the rtt_gazebo stack instead.
* Contributors: Johannes Meyer

0.3.3 (2014-05-27)
------------------

0.3.2 (2014-03-30)
------------------
* Made hector_gazebo and hector_sensors_gazebo true metapackages
* Contributors: Johannes Meyer

0.3.1 (2013-09-23)
------------------

0.3.0 (2013-09-02)
------------------
* Catkinization of stack hector_gazebo
