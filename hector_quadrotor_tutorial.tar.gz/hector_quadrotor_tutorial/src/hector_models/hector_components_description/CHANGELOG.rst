^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package hector_components_description
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.3.2 (2014-09-01)
------------------
* increased maximum torque for camera servos in vision_box_common.gazebo.xacro
* adapted urdf for asus xtion and added camera variables
* Add simple ps eye geometry
* Contributors: Johannes Meyer, Stefan Kohlbrecher

0.3.1 (2014-03-30)
------------------
* Re-parent LIDAR and camera mount to top_box_link
* Add xacro macros for setting dimensions
* Remove obsolete files
* Add UTM-30LX macro to vision box xacro
* Add hector ugv vision box to hector_components_description package for better reusability
* Contributors: Stefan Kohlbrecher
